/**
 * Brand a validated UUID as a local-file identity.
 * @param value - UUID already validated at its trust boundary.
 * @returns branded local-file identity.
 */
export function LocalFileId(value) {
    return value;
}
/** Raw-body import endpoint owned by this plugin. */
export const LOCAL_FILE_IMPORT_PATH = '/local-files/v1/import';
/** Same-origin download endpoint (GET) for a stored local file. */
export const LOCAL_FILE_DOWNLOAD_PATH = '/local-files/v1/download';
/** Same-origin preview endpoint (GET) returning `inline` disposition for thumbnails. */
export const LOCAL_FILE_PREVIEW_PATH = '/local-files/v1/preview';
/** Storage metadata format. */
export const LOCAL_FILE_METADATA_VERSION = 2;
//# sourceMappingURL=protocol.js.map