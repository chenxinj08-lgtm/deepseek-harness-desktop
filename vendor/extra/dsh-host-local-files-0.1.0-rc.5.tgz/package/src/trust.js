function parseAuthority(authority) {
    try {
        return new URL(`http://${authority}`);
    }
    catch {
        return undefined;
    }
}
function explicitPort(authority, parsed) {
    if (parsed.port !== '')
        return parsed.port;
    return new URL(`https://${authority}`).port;
}
function canonicalAuthority(authority, parsed) {
    const port = explicitPort(authority, parsed);
    return port === '' ? parsed.hostname : `${parsed.hostname}:${port}`;
}
/**
 * Reject a configured authority that WHATWG parsing would silently rewrite.
 * @param authority - configured bare host or host:port value.
 */
export function assertTrustedAuthority(authority) {
    const parsed = parseAuthority(authority);
    if (parsed !== undefined && canonicalAuthority(authority, parsed) === authority.toLowerCase())
        return;
    throw new Error(`host-local-files: trustedHosts entry ${JSON.stringify(authority)} is not a bare host[:port] authority`);
}
function isLoopbackHostname(hostname) {
    if (hostname === 'localhost' || hostname === '[::1]')
        return true;
    const parts = hostname.split('.');
    return parts.length === 4
        && parts[0] === '127'
        && parts.every(part => /^\d{1,3}$/u.test(part) && Number(part) <= 255);
}
function isTrustedAuthority(host, trustedHosts) {
    return trustedHosts.some((authority) => {
        const parsed = parseAuthority(authority);
        if (parsed === undefined)
            return false;
        return explicitPort(authority, parsed) === ''
            ? parsed.hostname === host.hostname
            : parsed.host === host.host;
    });
}
/**
 * Permit loopback or configured Host authorities and same-origin browser initiators.
 * @param req - incoming import request.
 * @param trustedHosts - validated deployment authorities.
 * @returns whether the request passes Host, Fetch Metadata, and Origin checks.
 */
export function isTrustedLocalFileRequest(req, trustedHosts) {
    const hostHeader = req.headers.host;
    if (hostHeader === undefined)
        return false;
    const host = parseAuthority(hostHeader);
    if (host === undefined)
        return false;
    if (!isLoopbackHostname(host.hostname) && !isTrustedAuthority(host, trustedHosts))
        return false;
    if (req.headers['sec-fetch-site'] === 'cross-site')
        return false;
    const origin = req.headers.origin;
    if (origin === undefined)
        return true;
    try {
        return new URL(origin).host === host.host;
    }
    catch {
        return false;
    }
}
//# sourceMappingURL=trust.js.map