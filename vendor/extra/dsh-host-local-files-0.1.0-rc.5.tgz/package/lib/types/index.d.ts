import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { LocalFileService } from './service.ts';
/** Cordis plugin name. */
export declare const name = "host-local-files";
/** Host services required by the endpoint and model-facing consumer. */
export declare const inject: string[];
/** Deployment policy for local file import and model-facing output. */
export interface Config {
    /** Absolute host-local staging root. */
    readonly storageRoot: string;
    /** Additional authorities allowed to call the loopback import endpoint. */
    readonly trustedHosts?: string[];
    /** Maximum accepted raw file size. */
    readonly maxFileBytes?: number;
    /** Maximum structured records returned by one read. */
    readonly maxReadRecords?: number;
    /** Maximum UTF-8 payload bytes returned by one structured read. */
    readonly maxReadBytes?: number;
    /** Maximum raw bytes returned by one binary-window read. */
    readonly maxBinaryReadBytes?: number;
    /** Maximum characters retained for one structured record. */
    readonly maxRecordChars?: number;
    /** Maximum matches returned by one search. */
    readonly maxSearchMatches?: number;
    /** Maximum characters retained around one search match. */
    readonly maxSearchExcerptChars?: number;
}
/** Plugin config schema; the Loader materializes every default before apply. */
export declare const Config: z<Config>;
/** Install the local service, endpoint, prompt section, and bounded tools. */
export declare function apply(ctx: Context, config: Config): Promise<void>;
export { LocalFileService };
//# sourceMappingURL=index.d.ts.map