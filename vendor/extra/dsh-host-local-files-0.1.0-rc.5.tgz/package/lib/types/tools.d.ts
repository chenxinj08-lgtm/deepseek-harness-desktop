import type { Context } from '@deepseek-ai/cordis';
import { LocalFileService } from './service.ts';
/** Model-facing output caps after config defaults are applied. */
export interface LocalFileToolCaps {
    readonly maxReadRecords: number;
    readonly maxReadBytes: number;
    readonly maxBinaryReadBytes: number;
    readonly maxRecordChars: number;
    readonly maxSearchMatches: number;
    readonly maxSearchExcerptChars: number;
}
/**
 * Register bounded local-file inspection, record, byte, and search tools.
 * @param ctx - plugin context owning tool and prompt registrations.
 * @param files - workspace-scoped local-file service.
 * @param caps - validated model-facing result limits.
 */
export declare function applyLocalFileTools(ctx: Context, files: LocalFileService, caps: LocalFileToolCaps): void;
//# sourceMappingURL=tools.d.ts.map