import type { LocalFileRecord } from './protocol.ts';
/** One semantic record exposed to read/search windowing. */
export interface LocalFileTextRecord {
    readonly index: number;
    readonly sheet?: string;
    readonly text: string;
}
/** Reader controls shared by every file family. */
export interface IterateOptions {
    readonly signal: AbortSignal;
    readonly sheet?: string;
    readonly onSheet?: (name: string) => void;
}
/**
 * Iterate logical records without materializing the complete file.
 * @param record - resolved immutable local-file payload.
 * @param options - cancellation, sheet selection, and sheet observation.
 * @returns lazy logical-record stream.
 */
export declare function iterateLocalFile(record: LocalFileRecord, options: IterateOptions): AsyncGenerator<LocalFileTextRecord>;
/**
 * Enumerate XLSX sheet names using the same streaming reader.
 * @param record - resolved immutable local-file payload.
 * @param signal - cancellation signal.
 * @returns workbook sheet names in file order, or an empty list for non-XLSX files.
 */
export declare function listWorkbookSheets(record: LocalFileRecord, signal: AbortSignal): Promise<string[]>;
//# sourceMappingURL=readers.d.ts.map