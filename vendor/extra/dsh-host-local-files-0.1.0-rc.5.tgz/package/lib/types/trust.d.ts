/** Same-origin and DNS-rebinding fence for the local-file HTTP endpoint. */
import type { IncomingMessage } from 'node:http';
/**
 * Reject a configured authority that WHATWG parsing would silently rewrite.
 * @param authority - configured bare host or host:port value.
 */
export declare function assertTrustedAuthority(authority: string): void;
/**
 * Permit loopback or configured Host authorities and same-origin browser initiators.
 * @param req - incoming import request.
 * @param trustedHosts - validated deployment authorities.
 * @returns whether the request passes Host, Fetch Metadata, and Origin checks.
 */
export declare function isTrustedLocalFileRequest(req: IncomingMessage, trustedHosts: readonly string[]): boolean;
//# sourceMappingURL=trust.d.ts.map