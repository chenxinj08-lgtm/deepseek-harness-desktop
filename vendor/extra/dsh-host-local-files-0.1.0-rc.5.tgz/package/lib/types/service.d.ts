import type { Readable } from 'node:stream';
import { Service } from '@deepseek-ai/cordis';
import type { Context } from '@deepseek-ai/cordis';
import { LocalFileId, type LocalFileImportResponse, type LocalFileRecord } from './protocol.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        localFiles: LocalFileService;
    }
}
/** Config already validated and defaulted by the plugin schema. */
export interface LocalFileServiceConfig {
    readonly storageRoot: string;
    readonly maxFileBytes: number;
}
/** Stable operational error used by both the route and model-facing tools. */
export declare class LocalFileError extends Error {
    readonly code: string;
    readonly status: number;
    /** @param code - stable machine-readable failure code. */
    constructor(code: string, message: string, status?: number);
}
interface ImportInput {
    readonly cwd: string;
    readonly id: LocalFileId;
    readonly name: string;
    readonly mediaType: string;
    readonly expectedSize: number;
    readonly body: Readable;
}
/** Service definition and local provider used by the import route and tool consumer. */
export declare class LocalFileService extends Service {
    private readonly config;
    private storageRoot;
    /** @param ctx - owning plugin context. */
    constructor(ctx: Context, config: LocalFileServiceConfig);
    /** Validate and create the private local store before publishing endpoint behavior. */
    initialize(): Promise<void>;
    /**
     * Validate an opaque local-file UUID received across HTTP or tool JSON.
     * @param value - untrusted identifier text.
     * @returns normalized branded identity.
     */
    parseId(value: string): LocalFileId;
    /**
     * Stream a raw request body into the local store and publish metadata atomically.
     * @param input - workspace, metadata, expected size, and raw byte stream.
     * @returns committed reference metadata for the browser.
     */
    importFile(input: ImportInput): Promise<LocalFileImportResponse>;
    /**
     * Resolve one file only within the calling session's canonical workspace.
     * @param cwd - calling session's workspace path.
     * @param id - validated local-file identity.
     * @returns immutable metadata and private payload path.
     */
    get(cwd: string, id: LocalFileId): Promise<LocalFileRecord>;
    /**
     * Read a file's complete payload with integrity re-verification.
     * @param cwd - calling session's workspace path.
     * @param id - validated local-file identity.
     * @returns verified full bytes plus stored media type and display name.
     */
    readWholeBytes(cwd: string, id: LocalFileId): Promise<{
        bytes: Buffer;
        mediaType: string;
        name: string;
    }>;
    private workspaceKey;
}
export {};
//# sourceMappingURL=service.d.ts.map