/** Host vision plugin: a "perception sensor" tool backed by a vision model. */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
/** Cordis plugin name. */
export declare const name = "host-vision";
/** Host services the observer depends on. */
export declare const inject: string[];
/** Deployment policy for the observer's vision-model call. */
export interface Config {
    /** Provider route key. Defaults to the built-in Xiaomi token-plan route. */
    readonly provider?: string;
    /** Vision model id. */
    readonly model?: string;
    /** Optional output-token cap; omitted means the model's own default budget. */
    readonly maxTokens?: number;
}
export declare const Config: z<Config>;
/** Observation modes the main model may request; auto reports everything in one call. */
export declare const VISION_MODES: readonly ["auto", "ocr", "ui", "objects", "chart", "compare", "region"];
export type VisionMode = (typeof VISION_MODES)[number];
/** One positioned visual evidence item. */
export interface VisionEvidenceObservation {
    category: 'text' | 'object' | 'layout' | 'number' | 'color' | 'ui-state';
    value: string;
    bbox: {
        x: number;
        y: number;
        width: number;
        height: number;
    } | null;
    confidence?: number;
}
/** One verbatim OCR span. */
export interface VisionEvidenceOcr {
    text: string;
    bbox: {
        x: number;
        y: number;
        width: number;
        height: number;
    } | null;
    confidence?: number;
}
/**
 * The sensor's normalized output: evidence only, never conclusions. The main
 * model interprets these facts; the sensor only reports what is visible.
 */
export interface VisionEvidence {
    imageId: string;
    status: 'ok' | 'partial' | 'unreadable';
    observations?: VisionEvidenceObservation[];
    ocr?: VisionEvidenceOcr[];
    notObserved?: string[];
    warnings?: string[];
}
/**
 * The sensor's discipline: report what is objectively visible, never answer,
 * advise, or interpret. This keeps the vision model an eye, not a second brain.
 */
export declare const SENSOR_SYSTEM: string;
/** Build the mode-specific request sent to the vision model. */
export declare function visionPrompt(mode: VisionMode, question?: string, region?: {
    x: number;
    y: number;
    width: number;
    height: number;
}): string;
/**
 * Parse the sensor's raw output and keep only the evidence fields. Malformed or
 * non-object output fails closed (callers retry once, then report the failure).
 */
export declare function sanitizeEvidence(raw: string, imageId: string): VisionEvidence;
/** Install the perception-sensor tool and its usage guidance. */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map