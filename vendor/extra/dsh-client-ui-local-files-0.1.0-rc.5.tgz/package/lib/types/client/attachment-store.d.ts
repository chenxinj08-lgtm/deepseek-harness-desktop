/** Independent per-session local-file attachment store (never mirrored into the draft). */
import type { SessionId } from '@deepseek-ai/dsh-client-runtime/client';
/** One staged local file as seen by the dock cards. */
export interface DraftRef {
    readonly id: string;
    readonly name: string;
    readonly size: number;
    readonly mediaType: string;
    readonly status: 'pending' | 'ready' | 'failed';
    /** Browser object URL for image thumbnails; revoked on remove/clear. */
    readonly previewUrl?: string;
}
interface InternalRef extends DraftRef {
    status: 'pending' | 'ready' | 'failed';
    previewUrl?: string;
    /** Resolves when the import settles; resolves to the local-file id. */
    promise: Promise<string>;
    abort: () => void;
}
export declare const subscribe: (listener: () => void) => (() => void);
export declare function refsOf(sessionId: SessionId): readonly DraftRef[];
export declare function removeRef(sessionId: SessionId, id: string): void;
export declare function clearRefs(sessionId: SessionId): void;
export declare function stageRef(sessionId: SessionId, entry: InternalRef): void;
export declare function markReady(sessionId: SessionId, id: string): void;
export declare function markFailedAndDrop(sessionId: SessionId, id: string): void;
/** Consume every staged attachment: wait for imports, return their ids, clear state. */
export declare function takeAllIds(sessionId: SessionId): {
    ids: Promise<string[]>;
};
export declare function hasStaged(sessionId: SessionId): boolean;
/** Whether any session currently has staged local files (composer send enablement). */
export declare function hasStagedAny(): boolean;
/** Abort and drop every session's staged attachments (plugin teardown). */
export declare function clearAllRefs(): void;
export {};
//# sourceMappingURL=attachment-store.d.ts.map