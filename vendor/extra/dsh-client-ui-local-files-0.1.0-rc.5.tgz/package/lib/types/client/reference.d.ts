/** Browser-local reference codec and import response validation. */
/** Source name stored on input-machine occurrences. */
export declare const LOCAL_FILE_SOURCE = "local-files";
/** Host endpoint; same-origin fetch keeps bytes on the Harness host transport. */
export declare const LOCAL_FILE_IMPORT_PATH = "/local-files/v1/import";
/** Same-origin download endpoint (GET) for a stored local file. */
export declare const LOCAL_FILE_DOWNLOAD_PATH = "/local-files/v1/download";
/** Minimal composer reference retained until submit serialization. */
export interface LocalFileReference {
    readonly id: string;
    readonly name: string;
    readonly size: number;
    readonly mediaType: string;
    /** Present after Host sniffing; omitted by an immediately staged browser reference. */
    readonly kind?: 'text' | 'csv' | 'xlsx' | 'docx' | 'binary';
}
/**
 * Validate an untrusted JSON response or occurrence payload.
 * @param value - parsed wire or occurrence value.
 * @returns validated local-file reference.
 */
export declare function parseLocalFileReference(value: unknown): LocalFileReference;
/**
 * Parse one opaque input-machine ref string.
 * @param ref - serialized occurrence reference.
 * @returns validated local-file reference.
 */
export declare function decodeLocalFileReference(ref: string): LocalFileReference;
/**
 * Serialize only small metadata; file bytes never enter the prompt.
 * @param ref - serialized occurrence reference.
 * @returns model-facing local-file marker.
 */
export declare function serializeLocalFileReference(ref: string): string;
/**
 * Produce the human-readable copy projection for one file chip.
 * @param ref - serialized occurrence reference.
 * @returns clipboard-safe identifier text.
 */
export declare function clipboardLocalFileReference(ref: string): string;
//# sourceMappingURL=reference.d.ts.map