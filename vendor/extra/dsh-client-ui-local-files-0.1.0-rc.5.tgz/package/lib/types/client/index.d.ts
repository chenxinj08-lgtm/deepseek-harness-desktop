/**
 * Browser plugin: same-origin import into an independent attachment state.
 *
 * Attachments never enter the composer draft. The picker/drop seats stage files
 * into a per-session store; the dock renders them as cards above the input; and
 * a listener on the official `conversation/send-content-inject` hook submits
 * them as structured `local-file` blocks alongside (never spliced into) the
 * text. The text area therefore stays plain user text — no `<local_file>`, no
 * U+FFFC placeholder, no chip, no cursor drift.
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
/** Required client services: session addressing, input mutation, and slot composition. */
export declare const inject: string[];
/** Register the independent attachment pipeline plus additive composer seats. */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map