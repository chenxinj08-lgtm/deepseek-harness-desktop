import type { PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
/** Async upload face injected from the apply closure. */
export interface LocalFileUploadInjected {
    readonly uploadFiles: (files: readonly File[]) => Promise<void>;
    readonly notifyError: (message: string) => void;
}
type PickerProps = PropsRuntime<'conversation.input.left'> & LocalFileUploadInjected;
type DropProps = PropsRuntime<'conversation.input.overlay'> & LocalFileUploadInjected;
type DockProps = PropsRuntime<'conversation.input.dock'>;
/** Compact file-picker control inside the composer tool row. */
export declare function LocalFilePicker({ uploadFiles }: PickerProps): import("react").JSX.Element;
/** Page-level drop/paste listener; the visible overlay appears only during a file drag. */
export declare function LocalFileDropOverlay({ uploadFiles }: DropProps): import("react").JSX.Element | null;
/** Attachment cards above the composer, rendered from the independent store. */
export declare function LocalFileDock({ session }: DockProps): import("react").JSX.Element | null;
export {};
//# sourceMappingURL=LocalFiles.d.ts.map