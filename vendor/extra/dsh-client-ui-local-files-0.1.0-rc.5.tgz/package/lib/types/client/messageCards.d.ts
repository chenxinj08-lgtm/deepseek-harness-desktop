/** Message-level enhancement: render <local_file …/> references as attachment cards. */
import type { SessionId } from '@deepseek-ai/dsh-client-runtime/client';
/** Parse one serialized <local_file …/> occurrence and return its attributes. */
export declare function parseLocalFileTag(text: string): {
    id: string;
    name: string;
    sizeBytes: number;
    kind: string;
} | null;
/** Walk a text container and replace each bare <local_file …/> with a clickable attachment card. */
export declare function enhanceMessageText(container: HTMLElement, sessionId: SessionId, downloadUrl: (sessionId: SessionId, id: string) => string): void;
/** Observe the conversation content region and enhance every rendered message once. */
export declare function installMessageEnhancer(getSessionId: () => SessionId | null): () => void;
//# sourceMappingURL=messageCards.d.ts.map