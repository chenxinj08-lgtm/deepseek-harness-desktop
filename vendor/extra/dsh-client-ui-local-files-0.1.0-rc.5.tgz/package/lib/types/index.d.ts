/** Host loader half; all product behavior lives in the browser client entry. */
export declare function apply(): void;
//# sourceMappingURL=index.d.ts.map