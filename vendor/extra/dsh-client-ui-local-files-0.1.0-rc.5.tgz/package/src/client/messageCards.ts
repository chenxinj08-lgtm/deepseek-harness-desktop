/** Message-level enhancement: render <local_file …/> references as attachment cards. */
import type { SessionId } from '@deepseek-ai/dsh-client-runtime/client'
import { LOCAL_FILE_DOWNLOAD_PATH } from './reference.ts'

/** Parse one serialized <local_file …/> occurrence and return its attributes. */
export function parseLocalFileTag(text: string): { id: string; name: string; sizeBytes: number; kind: string } | null {
  const match = /<local_file\s+id="([0-9a-f-]+)"\s+name="([^"]*)"\s+size_bytes="(\d+)"\s+kind="([a-z]+)"\s*\/>/u.exec(text)
  if (match === null) return null
  return { id: match[1]!, name: match[2]!, sizeBytes: Number(match[3]!), kind: match[4]! }
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${String(bytes)} B`
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / 1024 / 1024).toFixed(1)} MB`
  return `${(bytes / 1024 / 1024 / 1024).toFixed(1)} GB`
}

const KIND_ICON: Record<string, string> = {
  xlsx: '<svg viewBox="0 0 16 16" width="16" height="16" fill="none" aria-hidden="true"><rect x="1.5" y="1.5" width="13" height="13" rx="1.5" stroke="currentColor"/><path d="M4 5h8M4 8h8M4 11h5" stroke="currentColor" stroke-linecap="round"/></svg>',
  docx: '<svg viewBox="0 0 16 16" width="16" height="16" fill="none" aria-hidden="true"><path d="M3 1.5h7l3 3v10H3z" stroke="currentColor" stroke-linejoin="round"/><path d="M10 1.5v3h3M5.5 8h5M5.5 11h5" stroke="currentColor" stroke-linecap="round"/></svg>',
  csv: '<svg viewBox="0 0 16 16" width="16" height="16" fill="none" aria-hidden="true"><rect x="1.5" y="1.5" width="13" height="13" rx="1.5" stroke="currentColor"/><path d="M4.5 5h7M4.5 8h7M4.5 11h7" stroke="currentColor" stroke-linecap="round"/></svg>',
  text: '<svg viewBox="0 0 16 16" width="16" height="16" fill="none" aria-hidden="true"><path d="M3 2h10v3H3zM3 7h10M3 10h10M3 13h10" stroke="currentColor" stroke-linecap="round"/></svg>',
  binary: '<svg viewBox="0 0 16 16" width="16" height="16" fill="none" aria-hidden="true"><rect x="1.5" y="1.5" width="13" height="13" rx="1.5" stroke="currentColor"/><path d="M5.5 4.5v7M10.5 4.5v7M4 9.5h3M8.5 9.5h3" stroke="currentColor" stroke-linecap="round"/></svg>',
}

/** Walk a text container and replace each bare <local_file …/> with a clickable attachment card. */
export function enhanceMessageText(container: HTMLElement, sessionId: SessionId, downloadUrl: (sessionId: SessionId, id: string) => string): void {
  const walker = document.createTreeWalker(container, NodeFilter.SHOW_TEXT)
  const texts: Text[] = []
  for (let node = walker.nextNode(); node !== null; node = walker.nextNode()) {
    texts.push(node as Text)
  }
  for (const text of texts) {
    const parsed = parseLocalFileTag(text.data)
    if (parsed === null) continue
    const { id, name, sizeBytes, kind } = parsed
    const anchor = document.createElement('a')
    anchor.className = 'dsh-lf-card'
    anchor.href = downloadUrl(sessionId, id)
    anchor.download = name
    anchor.title = '点击下载原始文件 · 模型可通过 local_file_* 工具按需读取'
    anchor.style.cssText = 'display:inline-flex;align-items:center;gap:7px;margin:2px 4px;padding:5px 10px 5px 8px;border:1px solid rgba(0,0,0,.1);border-radius:9px;background:#f7f8fa;color:#1d1d1f;text-decoration:none;font:12px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC",sans-serif;vertical-align:middle;cursor:pointer;user-select:none'
    const icon = document.createElement('span')
    icon.style.cssText = 'display:inline-flex;color:#5b6472;flex:none'
    icon.innerHTML = KIND_ICON[kind] ?? KIND_ICON.binary!
    const label = document.createElement('span')
    label.style.cssText = 'max-width:240px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:500'
    label.textContent = name
    const meta = document.createElement('span')
    meta.style.cssText = 'color:#8a909a;flex:none'
    meta.textContent = formatBytes(sizeBytes)
    anchor.append(icon, label, meta)
    text.replaceWith(anchor)
  }
}

/** Observe the conversation content region and enhance every rendered message once. */
export function installMessageEnhancer(getSessionId: () => SessionId | null): () => void {
  const downloadUrl = (sessionId: SessionId, id: string): string => {
    const url = new URL(LOCAL_FILE_DOWNLOAD_PATH, window.location.origin)
    url.searchParams.set('session_id', sessionId)
    url.searchParams.set('file_id', id)
    return url.toString()
  }
  const enhanced = new WeakSet<Element>()
  const enhance = (): void => {
    const sessionId = getSessionId()
    if (sessionId === null) return
    const nodes = document.querySelectorAll<HTMLElement>('[data-dsh-message-content], .prose')
    for (const node of nodes) {
      if (enhanced.has(node)) continue
      enhanced.add(node)
      if (node.querySelector('.dsh-lf-card') === null) {
        enhanceMessageText(node, sessionId, downloadUrl)
      }
    }
  }
  enhance()
  const observer = new MutationObserver(() => { enhance() })
  if (document.body !== null) {
    observer.observe(document.body, { childList: true, subtree: true })
  } else {
    document.addEventListener('DOMContentLoaded', () => {
      observer.observe(document.body, { childList: true, subtree: true })
    }, { once: true })
  }
  return () => observer.disconnect()
}
